#pragma once
#include"TextReader.hpp"
void find_predicate();