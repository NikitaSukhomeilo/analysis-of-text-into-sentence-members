#pragma once
#include <sstream>
#include <algorithm>
#include"TextReader.hpp"
using namespace std;
void find_addition();