#pragma once
#include"TextReader.hpp"
void find_definitions();