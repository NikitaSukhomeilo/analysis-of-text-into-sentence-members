#pragma once
#include"TextReader.hpp"
#include <iostream>
#include <string>
#include <fstream>
#include <conio.h>
#include <iomanip>
#include <Windows.h>
#include <vector>
void find_subjects();